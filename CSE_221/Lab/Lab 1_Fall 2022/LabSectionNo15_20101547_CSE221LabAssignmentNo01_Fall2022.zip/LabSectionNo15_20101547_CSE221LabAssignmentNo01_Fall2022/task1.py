#1(1)
hola=open("input1a.txt", "r")#takes input from the same directory
content=hola.read() #read the file
with open("output1a.txt", "w") as content_file: #creates an output file
    val=content.split() #using input file, splits the string into a list
    inp=val[0] #takes the first value for input
    for i in val[1:]: #runs the whole list to iterate
        if int(i) % 2 == 0: #checks if the number is even
            content_file.write(f"{i} is an Even number.\n")
        else:
            content_file.write(f"{i} is an Odd number.\n")
hola.close() #closes the file