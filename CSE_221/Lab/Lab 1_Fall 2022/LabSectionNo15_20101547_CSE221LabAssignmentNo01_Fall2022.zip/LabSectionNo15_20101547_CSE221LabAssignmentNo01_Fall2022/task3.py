#3
"""The algorithm provided here compares all items in the list regardless of
whether the list is already sorted or not.Comparing all values is a waste of
time and resources if the given list has already been sorted.By improving the bubble sort,
we can cut down on time and resources spent on pointless iterations."""


hola=open("input3.txt", "r")#takes input from the same directory
content=hola.read() #read the file
with open("output3.txt", "w") as content_file: #creates an output file
    val=content.split()
    list_0=[]
    for x in val[1:]:
        list_0.append(int(x))
    def bubbleSort(array):
        for i in range(len(array)):# loop through each element of array
            swapped_already = False #tracks swapping
            for j in range(0, len(array) - i - 1):
                if array[j] > array[j + 1]:# compare two adjacent elements
                    temp = array[j]# We need to swap if elements are not in the right order
                    array[j] = array[j + 1]
                    array[j + 1] = temp
                    swapped_already = True
            if not swapped_already: #If the array is already sorted, then break the loop
                break
    inp = list_0
    bubbleSort(inp)
    for m in inp: #wrtiting it in the output file
        content_file.write(f"{m} ")
