def asci(var):
    sum=0
    for i in var:
        sum+=ord(i)
    return sum

def convert(tm):
  lis=tm.split(':')
  time=int(lis[0])+int(lis[-1])/60
  return time

def selsort(a):
    for i in range(len(a)):
        min = i
        for j in range(i + 1, len(a)):
            if a[min] > a[j]:
                min = j
        a[i], a[min] = a[min], a[i]
    return a


count=0
with open("input5.txt", "r") as file:
  num=file.readline()
  name=[]
  val_0=[]
  place_0=[]
  time_0=[]

  for i in range(int(num)):
      sen=file.readline()
      lis=sen.split()
      name.append(lis[0])
      place_0.append(lis[-3])
      time_0.append(lis[-1])

  for i in name:
      value=asci(i)
      val_0.append(value)

  for i in range(len(val_0)):#sort based on asci value
      min_num=val_0[i]
      nam=name[i]
      min_ind=i
      for j in range(i+1,len(val_0)):
          if val_0[j]<min_num:
              min_num=val_0[j]
              min_ind = j
              nam=name[j]

      val_0[i],val_0[min_ind]=val_0[min_ind],val_0[i]
      name[i],name[min_ind]=name[min_ind],name[i]
      place_0[i],place_0[min_ind]=place_0[min_ind],place_0[i]
      time_0[i],time_0[min_ind]=time_0[min_ind],time_0[i]


  for i in range(len(val_0)): #sorting based on alphabetical order
      nam=name[i]
      min_ind=i
      for j in range(i+1,len(val_0)):
          if ord(nam[0])>ord(name[j][0]):
              min_ind = j
              nam=name[j]

      val_0[i],val_0[min_ind]=val_0[min_ind],val_0[i]
      name[i],name[min_ind]=name[min_ind],name[i]
      place_0[i],place_0[min_ind]=place_0[min_ind],place_0[i]
      time_0[i],time_0[min_ind]=time_0[min_ind],time_0[i]





  file_o=open("output5.txt","w")
  for i in range(len(name)):
      file_o.write(f"{name[i]} will departure for {place_0[i]} at {time_0[i]}"+"\n")
  file_o.close()