#Task_4
input4_testCase1 = open("input4.txt", "rt")
output4 = open("output4.txt", "w")

N_0 = int(input4_testCase1.readline().strip())
val = (input4_testCase1.readlines())


id_y = val[0].split()# Making a list of Student ID's.
Si = [0]*N_0#print(Student id's)
idx_Si = 0
for i in id_y:
  Si[idx_Si] = int(i)
  idx_Si += 1


marks_0 = val[1].split()# making a list of student marks.
#print(marks)
Sm = [0]*N_0
idx_Sm = 0
for i in marks_0:
  Sm[idx_Sm] = int(i)
  idx_Sm += 1

for i in range(len(Sm)): #Selection sort applied to have minimum swaps
  for j in range(i):
    if Sm[j]<Sm[i]:
      temp_Sm = Sm[j]# swapping marks array
      Sm[j] = Sm[i]
      Sm[i] = temp_Sm
      temp_Si = Si[j]# swapping ID array
      Si[j] = Si[i]
      Si[i] = temp_Si

min_0 = 0
for i in range(N_0):# Sorting ID array when more than one individual have the same marks.
  for i in range(N_0-1):
    if Sm[i] == Sm[i+1]:
      if Si[i] > Si[i+1]:
        Temp = Si[i]
        Si[i] = Si[i+1]
        Si[i+1] = Temp

for i in range(N_0):#creating the text file to write answers
  ans = f"ID: {Si[i]} Mark: {Sm[i]} \n"
  output4.write(ans)

input4_testCase1.close() #closing the input file
output4.close() #closing the file